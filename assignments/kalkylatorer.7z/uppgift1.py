# ~ Anton Lundmark ~

def addition(term1, term2):
    print("Addition Result:")
    print((float(term1)) + (float(term2)))

def subtraction(term1, term2):
    print("Subtraction Result:")
    print((float(term1)) - (float(term2)))

def multiplication(factor1, factor2):
    print("Multiplication Result:")
    print((float(factor1)) * (float(factor2)))

def division(numerator, denominator):
    print("Division Result:")
    print((float(numerator)) / (float(denominator)))

def average(value1, value2):
    print("Average Result:")
    print(((float(value1)) + (float(value2))) / 2)

#Change any values here for different results
addition(2, 2)
subtraction(5, 4)
multiplication(5, 4)
division(128, 64)
average(5, 10)